/***************************************************************/
/*                                                             */
/*   ARM Instruction Level Simulator                           */
/*                                                             */
/*   CMSC-22200 Computer Architecture                          */
/*   University of Chicago                                     */
/*                                                             */
/***************************************************************/

#include "bp.h"
#include <stdlib.h>
#include <stdio.h>


void bp_predict(/*......*/)
{
    /* Predict next PC */
}

void bp_update(/*......*/)
{
    /* Update BTB */


    /* Update gshare directional predictor */


    /* Update global history register */

}
